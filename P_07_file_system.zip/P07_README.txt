F�r das MC1 Praktikum P_07 File Systems gibt es kein Programmrahmen!
Das Praktikum baut auf dem Programmrahmen vom P_05/P_06 Motion Sensor.